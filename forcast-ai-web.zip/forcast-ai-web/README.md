# Forcast AI — projet web prêt pour Vercel

Cette version reprend l’interface React fournie et ajoute la structure Vite, Tailwind CSS et une fonction serveur `/api/chat` pour appeler Gemini sans exposer la clé API dans le navigateur.

## Déploiement simple

1. Créez un compte sur GitHub et Vercel.
2. Créez un dépôt GitHub privé nommé `forcast-ai`.
3. Téléversez tous les fichiers de ce dossier dans le dépôt (pas uniquement `App.jsx`).
4. Dans Vercel, choisissez **Add New → Project**, puis importez le dépôt GitHub.
5. Gardez les paramètres de build par défaut de Vite :
   - Build command : `npm run build`
   - Output directory : `dist`
6. Avant ou après le premier déploiement, ouvrez **Settings → Environment Variables** dans Vercel et ajoutez :
   - Name : `GEMINI_API_KEY`
   - Value : votre clé API Google AI Studio
   - Environments : Production, Preview et Development selon votre besoin
7. Cliquez sur **Redeploy**. Vercel fournira une adresse publique `*.vercel.app`.

## Tester localement (facultatif)

```bash
npm install
npm run dev
```

Pour tester la fonction API `/api/chat` localement, utilisez Vercel CLI (`vercel dev`) après avoir configuré `GEMINI_API_KEY` dans les variables d’environnement.

## Limites fonctionnelles à connaître dans cette version

- L’importation actuelle lit les fichiers CSV/TXT ; le véritable import Excel `.xlsx` n’est pas encore implémenté.
- L’historique est stocké dans le `localStorage` du navigateur : il n’est pas partagé entre plusieurs appareils ou utilisateurs.
- Le panneau Supabase est actuellement une interface de configuration ; la synchronisation Supabase n’est pas encore implémentée.
- Les données de démonstration sont fictives et doivent être identifiées comme telles lors de la présentation.
- Les indicateurs de précision sont des évaluations simplifiées ; ils doivent être améliorés par un backtesting chronologique avant toute utilisation métier.
