export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Méthode non autorisée.' });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
  if (!apiKey) {
    return res.status(503).json({ error: 'La clé GEMINI_API_KEY doit être configurée dans les variables d’environnement Vercel.' });
  }

  const prompt = req.body?.prompt;
  if (typeof prompt !== 'string' || !prompt.trim()) {
    return res.status(400).json({ error: 'Le message est vide.' });
  }

  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': apiKey,
      },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
    });

    const payload = await response.json();
    if (!response.ok) {
      return res.status(response.status).json({ error: payload?.error?.message || 'Erreur de l’API Gemini.' });
    }

    const reply = payload?.candidates?.[0]?.content?.parts?.map((part) => part.text || '').join('\n').trim();
    return res.status(200).json({ reply: reply || 'Gemini n’a pas retourné de réponse.' });
  } catch (error) {
    return res.status(500).json({ error: 'Impossible de contacter Gemini pour le moment.' });
  }
}
