import React, { useState, useEffect, useMemo, useRef } from 'react';

// ==========================================
// 1. ENGINE STATISTIQUE & ALGOS DE PRÉVISION
// ==========================================

/**
 * Calcul de la Régression Linéaire (Moindres Carrés Ordinaires - OLS)
 */
function calculateLinearRegression(data, horizon) {
  const n = data.length;
  if (n === 0) return { fitted: [], predictions: [], slope: 0, intercept: 0 };

  let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
  for (let i = 0; i < n; i++) {
    sumX += i;
    sumY += data[i];
    sumXY += i * data[i];
    sumX2 += i * i;
  }

  const denominator = (n * sumX2 - sumX * sumX);
  const slope = denominator !== 0 ? (n * sumXY - sumX * sumY) / denominator : 0;
  const intercept = (sumY - slope * sumX) / n;

  const fitted = data.map((_, i) => Math.max(0, slope * i + intercept));

  const predictions = [];
  for (let h = 1; h <= horizon; h++) {
    const t = n - 1 + h;
    predictions.push(Math.max(0, slope * t + intercept));
  }

  return { fitted, predictions, slope, intercept };
}

/**
 * Calcul de la Moyenne Mobile Simple (SMA-3)
 */
function calculateMovingAverage(data, horizon, windowSize = 3) {
  const n = data.length;
  if (n === 0) return { fitted: [], predictions: [] };

  const fitted = [];
  for (let i = 0; i < n; i++) {
    if (i < windowSize - 1) {
      fitted.push(data[i]);
    } else {
      let sum = 0;
      for (let j = 0; j < windowSize; j++) {
        sum += data[i - j];
      }
      fitted.push(sum / windowSize);
    }
  }

  const predictions = [];
  let currentWindow = data.slice(-windowSize);
  for (let h = 0; h < horizon; h++) {
    const avg = currentWindow.reduce((a, b) => a + b, 0) / windowSize;
    predictions.push(Math.max(0, avg));
    currentWindow.shift();
    currentWindow.push(avg);
  }

  return { fitted, predictions };
}

/**
 * Lissage Exponentiel Triple de Holt-Winters (Saisonnier Additif)
 */
function calculateHoltWinters(data, horizon, period = 12, alpha = 0.3, beta = 0.1, gamma = 0.3) {
  const n = data.length;
  if (n < period * 2) {
    const lr = calculateLinearRegression(data, horizon);
    return { fitted: lr.fitted, predictions: lr.predictions, isFallback: true };
  }

  let level = 0;
  for (let i = 0; i < period; i++) level += data[i];
  level /= period;

  let trend = 0;
  for (let i = 0; i < period; i++) {
    trend += (data[i + period] - data[i]) / period;
  }
  trend /= period;

  const seasonal = new Array(period).fill(0);
  for (let i = 0; i < period; i++) {
    seasonal[i] = data[i] - level;
  }

  const levels = [level];
  const trends = [trend];
  const seasonals = [...seasonal];
  const fitted = [];

  for (let i = 0; i < n; i++) {
    const val = data[i];
    const prevLevel = levels[i];
    const prevTrend = trends[i];
    const sIdx = i % period;
    const prevSeasonal = seasonals[sIdx];

    const newLevel = alpha * (val - prevSeasonal) + (1 - alpha) * (prevLevel + prevTrend);
    const newTrend = beta * (newLevel - prevLevel) + (1 - beta) * prevTrend;
    const newSeasonal = gamma * (val - newLevel) + (1 - gamma) * prevSeasonal;

    levels.push(newLevel);
    trends.push(newTrend);
    seasonals.push(newSeasonal);

    fitted.push(Math.max(0, prevLevel + prevTrend + prevSeasonal));
  }

  const lastLevel = levels[levels.length - 1];
  const lastTrend = trends[trends.length - 1];

  const predictions = [];
  for (let h = 1; h <= horizon; h++) {
    const sIdx = (n + h - 1) % period;
    const predVal = lastLevel + h * lastTrend + seasonals[sIdx];
    predictions.push(Math.max(0, predVal));
  }

  return { fitted, predictions, isFallback: false };
}

/**
 * Évaluation des modèles (Backtesting & Métriques d'erreur MAE, RMSE, MAPE)
 */
function evaluateModel(actuals, fitted) {
  const testSize = Math.min(6, Math.floor(actuals.length * 0.25));
  if (testSize <= 0) return { MAE: 0, RMSE: 0, MAPE: 0 };

  const actualTest = actuals.slice(-testSize);
  const fittedTest = fitted.slice(-testSize);

  let sumAbsError = 0;
  let sumSqError = 0;
  let sumPercError = 0;
  let validPercCount = 0;

  for (let i = 0; i < testSize; i++) {
    const act = actualTest[i];
    const fit = fittedTest[i];
    const err = act - fit;

    sumAbsError += Math.abs(err);
    sumSqError += err * err;

    if (act !== 0) {
      sumPercError += Math.abs(err / act);
      validPercCount++;
    }
  }

  const MAE = sumAbsError / testSize;
  const RMSE = Math.sqrt(sumSqError / testSize);
  const MAPE = validPercCount > 0 ? (sumPercError / validPercCount) * 100 : 0;

  return {
    MAE: Math.round(MAE * 100) / 100,
    RMSE: Math.round(RMSE * 100) / 100,
    MAPE: Math.round(MAPE * 10) / 10
  };
}

// ==========================================
// 2. DONNÉES DÉMO & FORMATTEURS
// ==========================================

const DEMO_DATASET = [
  { date: '2024-01', revenue: 42000, volume: 350 },
  { date: '2024-02', revenue: 45000, volume: 380 },
  { date: '2024-03', revenue: 52000, volume: 420 },
  { date: '2024-04', revenue: 49000, volume: 400 },
  { date: '2024-05', revenue: 58000, volume: 470 },
  { date: '2024-06', revenue: 64000, volume: 510 },
  { date: '2024-07', revenue: 61000, volume: 490 },
  { date: '2024-08', revenue: 55000, volume: 440 },
  { date: '2024-09', revenue: 68000, volume: 540 },
  { date: '2024-10', revenue: 74000, volume: 590 },
  { date: '2024-11', revenue: 82000, volume: 650 },
  { date: '2024-12', revenue: 95000, volume: 780 },
  { date: '2025-01', revenue: 53000, volume: 430 },
  { date: '2025-02', revenue: 56000, volume: 450 },
  { date: '2025-03', revenue: 65000, volume: 520 },
  { date: '2025-04', revenue: 62000, volume: 500 },
  { date: '2025-05', revenue: 73000, volume: 580 },
  { date: '2025-06', revenue: 81000, volume: 640 },
  { date: '2025-07', revenue: 78000, volume: 620 },
  { date: '2025-08', revenue: 70000, volume: 560 },
  { date: '2025-09', revenue: 86000, volume: 680 },
  { date: '2025-10', revenue: 92000, volume: 730 },
  { date: '2025-11', revenue: 104000, volume: 810 },
  { date: '2025-12', revenue: 121000, volume: 940 }
];

function formatCurrency(amount) {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(amount || 0);
}

function formatNumber(num) {
  return new Intl.NumberFormat('fr-FR').format(Math.round(num || 0));
}

function addMonthsToDate(lastDateStr, monthsToAdd) {
  const [year, month] = (lastDateStr || '2025-12').split('-').map(Number);
  const d = new Date(year, month - 1 + monthsToAdd, 1);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  return `${y}-${m}`;
}

// ==========================================
// 3. ICÔNES VECTORIELLES MINIMALISTES
// ==========================================

const Icons = {
  Dashboard: () => (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" d="M3 13.2l4.478-4.478a1.5 1.5 0 012.122 0l2.8 2.8a1.5 1.5 0 002.121 0L21 5m0 0h-5m5 0v5M3 21h18" />
    </svg>
  ),
  Import: () => (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
    </svg>
  ),
  Forecast: () => (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
    </svg>
  ),
  Bot: () => (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" d="M13 10V3L4 14h7v7l9-11h-7z" />
    </svg>
  ),
  History: () => (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ),
  Settings: () => (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
  ),
  Sparkles: () => (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
    </svg>
  ),
  Send: () => (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
    </svg>
  ),
  Check: () => (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M5 13l4 4L19 7" />
    </svg>
  ),
  Trash: () => (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
    </svg>
  ),
  Menu: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
    </svg>
  ),
  Close: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
    </svg>
  ),
  TrendUp: () => (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
    </svg>
  )
};

// ==========================================
// 4. GRAPHIQUE INTERACTIF SVG THÈME VERT PREMIUM
// ==========================================

const PremiumGreenChart = ({ historicalData, modelResults, selectedHorizon, targetMetric }) => {
  const [hoveredPoint, setHoveredPoint] = useState(null);

  if (!historicalData || historicalData.length === 0) return null;

  const actuals = historicalData.map(d => d[targetMetric]);
  const dates = historicalData.map(d => d.date);

  const lastDate = dates[dates.length - 1];
  const futureDates = Array.from({ length: selectedHorizon }, (_, i) => addMonthsToDate(lastDate, i + 1));
  const allDates = [...dates, ...futureDates];

  // Series compilées
  const lrFull = [...(modelResults.lr?.fitted || []), ...(modelResults.lr?.predictions || [])];
  const maFull = [...(modelResults.ma?.fitted || []), ...(modelResults.ma?.predictions || [])];
  const hwFull = [...(modelResults.hw?.fitted || []), ...(modelResults.hw?.predictions || [])];

  const allValues = [...actuals, ...lrFull, ...maFull, ...hwFull].filter(v => v !== undefined && !isNaN(v));
  const maxVal = Math.max(...allValues, 1000) * 1.12;
  const minVal = 0;

  const width = 850;
  const height = 360;
  const paddingLeft = 65;
  const paddingRight = 35;
  const paddingTop = 25;
  const paddingBottom = 45;

  const chartWidth = width - paddingLeft - paddingRight;
  const chartHeight = height - paddingTop - paddingBottom;

  const getX = (index) => paddingLeft + (index / (allDates.length - 1)) * chartWidth;
  const getY = (val) => paddingTop + chartHeight - ((val - minVal) / (maxVal - minVal)) * chartHeight;

  const buildPath = (dataArr) => {
    return dataArr.map((val, idx) => `${idx === 0 ? 'M' : 'L'} ${getX(idx).toFixed(1)} ${getY(val).toFixed(1)}`).join(' ');
  };

  const actualPath = actuals.map((val, idx) => `${idx === 0 ? 'M' : 'L'} ${getX(idx).toFixed(1)} ${getY(val).toFixed(1)}`).join(' ');
  const hwPath = buildPath(hwFull);
  const lrPath = buildPath(lrFull);
  const maPath = buildPath(maFull);

  const splitX = getX(dates.length - 1);

  // Intervalle de confiance pastel pour Holt-Winters
  const hwPredPoints = modelResults.hw?.predictions || [];
  let confidencePath = '';
  if (hwPredPoints.length > 0) {
    const topPoints = [];
    const bottomPoints = [];
    hwPredPoints.forEach((val, idx) => {
      const realIdx = dates.length + idx;
      const margin = val * (0.04 + idx * 0.015);
      topPoints.push(`${getX(realIdx).toFixed(1)},${getY(val + margin).toFixed(1)}`);
      bottomPoints.unshift(`${getX(realIdx).toFixed(1)},${getY(Math.max(0, val - margin)).toFixed(1)}`);
    });
    const firstPredX = getX(dates.length - 1).toFixed(1);
    const firstPredY = getY(actuals[actuals.length - 1]).toFixed(1);
    confidencePath = `M ${firstPredX},${firstPredY} L ` + topPoints.join(' L ') + ' L ' + bottomPoints.join(' L ') + ' Z';
  }

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm relative overflow-hidden transition-all duration-200 hover:shadow-md">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#168568]"></span>
            <h3 className="text-[#123D32] font-bold text-lg">Projections Temporelles & Comparatif Modèles</h3>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">Calculs en temps réel sur la métrique : <span className="font-semibold text-[#168568]">{targetMetric === 'revenue' ? "Chiffre d'Affaires (€)" : 'Volume de Ventes'}</span></p>
        </div>

        {/* Légende du graphique */}
        <div className="flex flex-wrap gap-4 text-xs font-medium">
          <span className="flex items-center gap-1.5 text-[#123D32]">
            <span className="w-3.5 h-1 rounded-full bg-[#123D32]"></span> Historique Réel
          </span>
          <span className="flex items-center gap-1.5 text-[#168568]">
            <span className="w-3.5 h-1 rounded-full bg-[#168568]"></span> Holt-Winters (Saisonnier)
          </span>
          <span className="flex items-center gap-1.5 text-[#38B987]">
            <span className="w-3.5 h-1 rounded-full bg-[#38B987] stroke-dasharray"></span> Reg. Linéaire
          </span>
          <span className="flex items-center gap-1.5 text-slate-400">
            <span className="w-3.5 h-1 rounded-full bg-slate-300"></span> Moyenne Mobile
          </span>
        </div>
      </div>

      <div className="relative w-full overflow-x-auto">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto min-w-[650px] select-none">
          <defs>
            {/* Dégradés Thème Vert */}
            <linearGradient id="pastelGreenGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#38B987" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#EAF6F0" stopOpacity="0.05" />
            </linearGradient>
            <linearGradient id="actualGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#123D32" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#123D32" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Grille horizontale épurée */}
          {[0, 0.25, 0.5, 0.75, 1].map((pct, i) => {
            const y = paddingTop + chartHeight * (1 - pct);
            const val = minVal + (maxVal - minVal) * pct;
            return (
              <g key={i}>
                <line x1={paddingLeft} y1={y} x2={width - paddingRight} y2={y} stroke="#F5F7F6" strokeWidth="1.5" />
                <text x={paddingLeft - 12} y={y + 4} textAnchor="end" fill="#94A3B8" fontSize="10" fontWait="500">
                  {targetMetric === 'revenue' ? `${Math.round(val / 1000)}k€` : Math.round(val)}
                </text>
              </g>
            );
          })}

          {/* Zones temporelles : Historique vs Futur */}
          <rect x={paddingLeft} y={paddingTop} width={splitX - paddingLeft} height={chartHeight} fill="#F5F7F6" opacity="0.4" rx="4" />
          <rect x={splitX} y={paddingTop} width={width - paddingRight - splitX} height={chartHeight} fill="#EAF6F0" opacity="0.35" rx="4" />
          <line x1={splitX} y1={paddingTop} x2={splitX} y2={height - paddingBottom} stroke="#168568" strokeDasharray="4 4" strokeWidth="1.5" />

          <text x={splitX - 10} y={paddingTop + 16} textAnchor="end" fill="#123D32" fontSize="10" fontWeight="700" letterSpacing="0.5">HISTORIQUE VÉRIFIÉ</text>
          <text x={splitX + 10} y={paddingTop + 16} textAnchor="start" fill="#168568" fontSize="10" fontWeight="700" letterSpacing="0.5">PRÉVISIONS (+{selectedHorizon} MOIS)</text>

          {/* Zone d'incertitude/confiance en vert pastel */}
          {confidencePath && <path d={confidencePath} fill="url(#pastelGreenGradient)" />}

          {/* Courbes des modèles secondaires */}
          <path d={lrPath} fill="none" stroke="#38B987" strokeWidth="2" strokeDasharray="4 4" opacity="0.85" />
          <path d={maPath} fill="none" stroke="#94A3B8" strokeWidth="1.8" opacity="0.7" />

          {/* Courbe Holt-Winters principale */}
          <path d={hwPath} fill="none" stroke="#168568" strokeWidth="3" />

          {/* Courbe Historique Majeure en Vert Foncé */}
          <path d={actualPath} fill="none" stroke="#123D32" strokeWidth="3.5" />

          {/* Points d'ancrage Historiques */}
          {actuals.map((val, idx) => (
            <circle
              key={`act-${idx}`}
              cx={getX(idx)}
              cy={getY(val)}
              r="4.5"
              fill="#FFFFFF"
              stroke="#123D32"
              strokeWidth="2.5"
              className="cursor-pointer transition-all hover:scale-150"
              onMouseEnter={() => setHoveredPoint({ idx, date: dates[idx], actual: val, type: 'actual' })}
              onMouseLeave={() => setHoveredPoint(null)}
            />
          ))}

          {/* Points d'ancrage Prévision */}
          {modelResults.hw?.predictions.map((val, idx) => {
            const realIdx = dates.length + idx;
            return (
              <circle
                key={`pred-${idx}`}
                cx={getX(realIdx)}
                cy={getY(val)}
                r="4.5"
                fill="#FFFFFF"
                stroke="#168568"
                strokeWidth="2.5"
                className="cursor-pointer transition-all hover:scale-150"
                onMouseEnter={() => setHoveredPoint({
                  idx: realIdx,
                  date: futureDates[idx],
                  hw: val,
                  lr: lrFull[realIdx],
                  ma: maFull[realIdx],
                  type: 'forecast'
                })}
                onMouseLeave={() => setHoveredPoint(null)}
              />
            );
          })}

          {/* Axe X - Dates */}
          {allDates.map((d, i) => {
            const step = Math.ceil(allDates.length / 10);
            if (i % step !== 0 && i !== allDates.length - 1) return null;
            return (
              <text key={`date-${i}`} x={getX(i)} y={height - paddingBottom + 22} textAnchor="middle" fill="#64748B" fontSize="10" fontWeight="500">
                {d}
              </text>
            );
          })}
        </svg>

        {/* Infobulle interactive élégante */}
        {hoveredPoint && (
          <div className="absolute top-4 right-4 bg-[#123D32] text-white p-3.5 rounded-xl shadow-xl border border-[#168568]/40 text-xs space-y-1.5 z-20 backdrop-blur-md animate-fadeIn">
            <div className="font-bold border-b border-emerald-800/80 pb-1 flex justify-between gap-4">
              <span>Période : {hoveredPoint.date}</span>
              <span className="text-[#38B987] text-[10px] uppercase font-bold tracking-wider">{hoveredPoint.type === 'actual' ? 'Réel' : 'Projection'}</span>
            </div>
            {hoveredPoint.type === 'actual' ? (
              <div className="text-emerald-300 font-bold text-sm">Réel : {targetMetric === 'revenue' ? formatCurrency(hoveredPoint.actual) : formatNumber(hoveredPoint.actual)}</div>
            ) : (
              <div className="space-y-1">
                <div className="text-[#38B987] font-bold">Holt-Winters : {targetMetric === 'revenue' ? formatCurrency(hoveredPoint.hw) : formatNumber(hoveredPoint.hw)}</div>
                <div className="text-emerald-200/80">Régression Linéaire : {targetMetric === 'revenue' ? formatCurrency(hoveredPoint.lr) : formatNumber(hoveredPoint.lr)}</div>
                <div className="text-slate-300">Moyenne Mobile : {targetMetric === 'revenue' ? formatCurrency(hoveredPoint.ma) : formatNumber(hoveredPoint.ma)}</div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

// ==========================================
// 5. APPLICATION PRINCIPALE FORCAST AI (VERT PREMIUM)
// ==========================================

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Data & Forecast States
  const [dataset, setDataset] = useState(DEMO_DATASET);
  const [horizon, setHorizon] = useState(6);
  const [targetMetric, setTargetMetric] = useState('revenue');
  const [historySaved, setHistorySaved] = useState([]);

  // API Key & Supabase Settings
  const [supabaseUrl, setSupabaseUrl] = useState('');
  const [supabaseKey, setSupabaseKey] = useState('');
  const [useSupabase, setUseSupabase] = useState(false);

  // Chatbot State
  const [chatMessages, setChatMessages] = useState([
    { role: 'assistant', text: "Bonjour ! Je suis l'assistant décisionnel de **Forcast AI**. Posez-moi vos questions sur la croissance, le choix du modèle de prévision ou la stratégie de stock." }
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);
  const chatEndRef = useRef(null);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('forcast_ai_history_green');
      if (saved) setHistorySaved(JSON.parse(saved));
    } catch (e) {
      console.error(e);
    }
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  // ==========================================
  // MOTEUR DE CALCUL DES MODÈLES
  // ==========================================
  const rawDataValues = useMemo(() => dataset.map(d => Number(d[targetMetric]) || 0), [dataset, targetMetric]);

  const modelResults = useMemo(() => {
    if (rawDataValues.length === 0) return { lr: null, ma: null, hw: null, bestModel: 'hw' };

    const lr = calculateLinearRegression(rawDataValues, horizon);
    const ma = calculateMovingAverage(rawDataValues, horizon, 3);
    const hw = calculateHoltWinters(rawDataValues, horizon, 12);

    const lrEval = evaluateModel(rawDataValues, lr.fitted);
    const maEval = evaluateModel(rawDataValues, ma.fitted);
    const hwEval = evaluateModel(rawDataValues, hw.fitted);

    lr.eval = lrEval;
    ma.eval = maEval;
    hw.eval = hwEval;

    let bestModel = 'hw';
    let lowestMAPE = hwEval.MAPE || 999;

    if (lrEval.MAPE < lowestMAPE && lrEval.MAPE > 0) {
      bestModel = 'lr';
      lowestMAPE = lrEval.MAPE;
    }
    if (maEval.MAPE < lowestMAPE && maEval.MAPE > 0) {
      bestModel = 'ma';
    }

    return { lr, ma, hw, bestModel };
  }, [rawDataValues, horizon]);

  // KPIs Dashboard
  const kpis = useMemo(() => {
    if (dataset.length === 0) return { totalRev: 0, totalVol: 0, avgMonthly: 0, momGrowth: 0, maxMonth: '-' };

    const totalRev = dataset.reduce((acc, curr) => acc + (Number(curr.revenue) || 0), 0);
    const totalVol = dataset.reduce((acc, curr) => acc + (Number(curr.volume) || 0), 0);
    const avgMonthly = totalRev / dataset.length;

    let sumGrowth = 0;
    for (let i = 1; i < dataset.length; i++) {
      const prev = dataset[i - 1].revenue || 1;
      const curr = dataset[i].revenue || 0;
      sumGrowth += ((curr - prev) / prev) * 100;
    }
    const momGrowth = dataset.length > 1 ? sumGrowth / (dataset.length - 1) : 0;
    const maxEntry = [...dataset].sort((a, b) => b.revenue - a.revenue)[0];

    return {
      totalRev,
      totalVol,
      avgMonthly,
      momGrowth: Math.round(momGrowth * 10) / 10,
      maxMonth: maxEntry ? `${maxEntry.date} (${formatCurrency(maxEntry.revenue)})` : '-'
    };
  }, [dataset]);

  // Import de fichier CSV/Excel
  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const text = evt.target.result;
        const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 0);
        if (lines.length < 2) return;

        const headers = lines[0].split(/[,;\t]/).map(h => h.trim().toLowerCase());
        const dateIdx = headers.findIndex(h => h.includes('date') || h.includes('mois') || h.includes('period'));
        const revIdx = headers.findIndex(h => h.includes('rev') || h.includes('ca') || h.includes('vente') || h.includes('chiffre'));
        const volIdx = headers.findIndex(h => h.includes('vol') || h.includes('quant') || h.includes('qte') || h.includes('unit'));

        const parsed = [];
        for (let i = 1; i < lines.length; i++) {
          const cols = lines[i].split(/[,;\t]/).map(c => c.trim());
          if (cols.length >= 2) {
            const dateStr = dateIdx !== -1 ? cols[dateIdx] : `Mois ${i}`;
            const revVal = revIdx !== -1 ? parseFloat(cols[revIdx].replace(/[^0-9.-]+/g, '')) : parseFloat(cols[1]);
            const volVal = volIdx !== -1 ? parseFloat(cols[volIdx].replace(/[^0-9.-]+/g, '')) : (parseFloat(cols[2]) || Math.round(revVal / 100));

            if (!isNaN(revVal)) {
              parsed.push({
                date: dateStr,
                revenue: revVal,
                volume: volVal || 100
              });
            }
          }
        }

        if (parsed.length > 0) {
          setDataset(parsed);
          setActiveTab('forecast');
        }
      } catch (err) {
        alert("Erreur lors du traitement du fichier CSV.");
      }
    };
    reader.readAsText(file);
  };

  const handleSaveForecast = () => {
    const bestObj = modelResults[modelResults.bestModel];
    const newEntry = {
      id: Date.now(),
      timestamp: new Date().toLocaleString('fr-FR'),
      targetMetric,
      horizon,
      datasetSize: dataset.length,
      bestModel: modelResults.bestModel.toUpperCase(),
      mape: bestObj?.eval?.MAPE,
      projectedSum: bestObj?.predictions?.reduce((a, b) => a + b, 0) || 0
    };

    const updated = [newEntry, ...historySaved];
    setHistorySaved(updated);
    localStorage.setItem('forcast_ai_history_green', JSON.stringify(updated));
    alert('Analyse enregistrée dans l\'historique.');
  };

  const handleDeleteHistory = (id) => {
    const updated = historySaved.filter(item => item.id !== id);
    setHistorySaved(updated);
    localStorage.setItem('forcast_ai_history_green', JSON.stringify(updated));
  };

  // Envoi Chatbot Gemini
  const handleSendChatMessage = async (e) => {
    e.preventDefault();
    if (!inputQuery.trim()) return;

    const userMsg = inputQuery;
    setInputQuery('');
    setChatMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsChatLoading(true);

    const bestObj = modelResults[modelResults.bestModel];
    const contextPrompt = `
Tu es l'Expert Senior en Prévision des Ventes de la plateforme Forcast AI.
Voici les données réelles de l'entreprise :
- Historique : ${dataset.length} mois.
- Chiffre d'Affaires Total : ${formatCurrency(kpis.totalRev)}.
- Croissance mensuelle moyenne MoM : ${kpis.momGrowth}%.
- Métrique prévisionnelle : ${targetMetric === 'revenue' ? 'Chiffre d\'Affaires' : 'Volume'}.
- Horizon calculé : +${horizon} mois.
- Meilleur Modèle Détecté : ${modelResults.bestModel.toUpperCase()} (MAPE : ${bestObj?.eval?.MAPE}%).
- Prévision cumulée sur les ${horizon} prochains mois : ${targetMetric === 'revenue' ? formatCurrency(bestObj?.predictions?.reduce((a,b)=>a+b,0)) : formatNumber(bestObj?.predictions?.reduce((a,b)=>a+b,0))}.

Question de l'utilisateur : "${userMsg}"
Réponds de manière professionnelle, structurée et stratégique.
`;

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: contextPrompt })
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data?.error || 'Erreur de connexion à Gemini.');
      const reply = data?.reply || "Analyse terminée d'après le modèle d'intelligence Forcast AI.";

      setChatMessages(prev => [...prev, { role: 'assistant', text: reply }]);
    } catch (err) {
      setChatMessages(prev => [...prev, {
        role: 'assistant',
        text: `Connexion à Gemini indisponible : ${err.message || 'vérifiez la configuration du serveur.'}`
      }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // Helper somme
  const sumArray = (arr) => (arr || []).reduce((a, b) => a + b, 0);

  return (
    <div className="flex h-screen bg-[#F5F7F6] text-slate-800 font-sans overflow-hidden antialiased select-none">

      {/* ================= SIDEBAR LATÉRALE VERT FONCÉ (#123D32) ================= */}
      <aside className={`fixed inset-y-0 left-0 z-40 w-64 bg-[#123D32] text-white flex flex-col justify-between transition-transform duration-300 md:static md:translate-x-0 ${
        mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <div>
          {/* LOGO PLATFORME */}
          <div className="h-20 flex items-center justify-between px-6 border-b border-emerald-900/60 bg-[#123D32]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#168568] to-[#38B987] flex items-center justify-center shadow-md shadow-emerald-950/40">
                <Icons.Forecast />
              </div>
              <div>
                <div className="font-black text-xl tracking-tight text-white flex items-center gap-1">
                  Forcast<span className="text-[#38B987]">.ai</span>
                </div>
                <div className="text-[9px] font-bold text-emerald-300 uppercase tracking-widest">ENTERPRISE BI</div>
              </div>
            </div>

            <button onClick={() => setMobileMenuOpen(false)} className="md:hidden text-slate-400 hover:text-white">
              <Icons.Close />
            </button>
          </div>

          {/* MENU NAVIGATION */}
          <nav className="p-4 space-y-1.5">
            {[
              { id: 'dashboard', label: 'Tableau de bord', icon: Icons.Dashboard },
              { id: 'data', label: 'Données & Import', icon: Icons.Import },
              { id: 'forecast', label: 'Prévisions & Modèles', icon: Icons.Forecast },
              { id: 'chat', label: 'Assistant IA Gemini', icon: Icons.Bot, badge: 'IA' },
              { id: 'history', label: 'Historique Analyses', icon: Icons.History, count: historySaved.length }
            ].map((item) => {
              const IconComp = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => { setActiveTab(item.id); setMobileMenuOpen(false); }}
                  className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-200 ${
                    isActive
                      ? 'bg-[#168568] text-white shadow-lg shadow-emerald-950/30'
                      : 'text-emerald-100/70 hover:bg-emerald-900/40 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <IconComp />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className="bg-[#38B987] text-[#123D32] text-[10px] font-bold px-2 py-0.5 rounded-full">
                      {item.badge}
                    </span>
                  )}
                  {item.count !== undefined && item.count > 0 && (
                    <span className="bg-emerald-900/80 text-emerald-200 text-xs px-2 py-0.5 rounded-md">
                      {item.count}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* PIED DE SIDEBAR - CONFIGURATION */}
        <div className="p-4 border-t border-emerald-900/60">
          <button
            onClick={() => { setActiveTab('settings'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
              activeTab === 'settings' ? 'bg-[#168568] text-white' : 'text-emerald-100/70 hover:bg-emerald-900/40 hover:text-white'
            }`}
          >
            <Icons.Settings /> Configuration API
          </button>
        </div>
      </aside>

      {/* ================= CONTENU PRINCIPAL EN VERT PASTEL/BLANC ================= */}
      <main className="flex-1 flex flex-col h-full overflow-hidden">

        {/* EN-TÊTE TOPBAR BLANC (#FFFFFF) */}
        <header className="h-20 bg-white border-b border-slate-200/80 px-8 flex items-center justify-between shrink-0 shadow-sm z-10">
          <div className="flex items-center gap-4">
            <button onClick={() => setMobileMenuOpen(true)} className="md:hidden text-slate-600 hover:text-[#123D32]">
              <Icons.Menu />
            </button>

            <div>
              <h1 className="text-xl font-extrabold text-[#123D32]">
                {activeTab === 'dashboard' && 'Tableau de Bord Stratégique'}
                {activeTab === 'data' && 'Données Commerciales & Importation'}
                {activeTab === 'forecast' && 'Prévision & Comparaison des Modèles'}
                {activeTab === 'chat' && 'Assistant IA Décisionnel Gemini'}
                {activeTab === 'history' && 'Historique des Rapports de Vente'}
                {activeTab === 'settings' && 'Paramètres système & Connexions'}
              </h1>
              <p className="text-xs text-slate-500 font-medium">Plateforme d'intelligence prédictive de ventes • V2.4</p>
            </div>
          </div>

          {/* ACTIONS RAPIDES TOPBAR */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 bg-[#EAF6F0] px-3 py-1.5 rounded-lg border border-[#38B987]/30">
              <span className="w-2 h-2 rounded-full bg-[#168568] animate-pulse"></span>
              <span className="text-xs font-bold text-[#123D32]">
                {dataset.length} Mois Historisés
              </span>
            </div>

            <button
              onClick={() => setDataset(DEMO_DATASET)}
              className="bg-[#168568] hover:bg-[#123D32] text-white text-xs font-bold px-4 py-2.5 rounded-xl transition-all shadow-sm flex items-center gap-2"
            >
              <Icons.Sparkles /> Charger Jeu Démo
            </button>
          </div>
        </header>

        {/* CONTENU SPÉCIFIQUE PAR ONGLET */}
        <div className="flex-1 overflow-y-auto p-8 space-y-6">

          {/* ================= TAB 1 : DASHBOARD ================= */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">

              {/* CARTES KPI (VERT PASTEL #EAF6F0 & DÉGRADE) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">

                {/* KPI 1 : CA TOTAL */}
                <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md relative overflow-hidden">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Chiffre d'Affaires</span>
                    <div className="w-10 h-10 rounded-xl bg-[#EAF6F0] text-[#168568] flex items-center justify-center font-bold">
                      €
                    </div>
                  </div>
                  <div className="text-2xl font-black text-[#123D32] mt-3">{formatCurrency(kpis.totalRev)}</div>
                  <div className="mt-2 flex items-center gap-2">
                    <span className="text-xs font-bold text-[#38B987] bg-[#EAF6F0] px-2 py-0.5 rounded-md flex items-center gap-1">
                      <Icons.TrendUp /> Validé
                    </span>
                    <span className="text-xs text-slate-500 font-medium">Sur {dataset.length} mois</span>
                  </div>
                </div>

                {/* KPI 2 : VOLUME DES VENTED */}
                <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Volume Vendu</span>
                    <div className="w-10 h-10 rounded-xl bg-[#EAF6F0] text-[#168568] flex items-center justify-center font-bold">
                      <Icons.Forecast />
                    </div>
                  </div>
                  <div className="text-2xl font-black text-[#123D32] mt-3">{formatNumber(kpis.totalVol)} units</div>
                  <div className="mt-2 text-xs text-slate-500 font-medium">
                    Moyenne : <span className="font-bold text-[#168568]">{formatNumber(kpis.totalVol / (dataset.length || 1))}/mois</span>
                  </div>
                </div>

                {/* KPI 3 : CROISSANCE MOM */}
                <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Taux Croissance (MoM)</span>
                    <div className="w-10 h-10 rounded-xl bg-[#EAF6F0] text-[#38B987] flex items-center justify-center font-bold">
                      %
                    </div>
                  </div>
                  <div className="text-2xl font-black text-[#123D32] mt-3">{kpis.momGrowth > 0 ? `+${kpis.momGrowth}%` : `${kpis.momGrowth}%`}</div>
                  <div className="mt-2 text-xs text-slate-500 font-medium">
                    Tendance mensuelle de fonds
                  </div>
                </div>

                {/* KPI 4 : PIC HISTORIQUE */}
                <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Meilleure Vente</span>
                    <div className="w-10 h-10 rounded-xl bg-[#EAF6F0] text-[#123D32] flex items-center justify-center font-bold">
                      <Icons.Sparkles />
                    </div>
                  </div>
                  <div className="text-base font-bold text-[#123D32] mt-3 truncate">{kpis.maxMonth}</div>
                  <div className="mt-2 text-xs text-[#168568] font-semibold">
                    Record absolu enregistré
                  </div>
                </div>
              </div>

              {/* GRAPHIQUE VERT PREMIUM */}
              <PremiumGreenChart
                historicalData={dataset}
                modelResults={modelResults}
                selectedHorizon={horizon}
                targetMetric={targetMetric}
              />

              {/* INSIGHTS DE BUSINESS INTELLIGENCE (VERT PASTEL #EAF6F0) */}
              <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm">
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-8 h-8 rounded-lg bg-[#EAF6F0] text-[#168568] flex items-center justify-center">
                    <Icons.Sparkles />
                  </div>
                  <h3 className="text-[#123D32] font-bold text-lg">Diagnostics & Détections Automatiques</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-[#EAF6F0]/60 border border-[#38B987]/30 p-4 rounded-xl">
                    <div className="text-xs font-extrabold text-[#123D32] uppercase tracking-wider">Algorithme Recommandé</div>
                    <div className="text-lg font-black text-[#168568] mt-1">{modelResults.bestModel.toUpperCase()}</div>
                    <p className="text-xs text-slate-600 mt-1">
                      Sélectionné car il présente l'erreur MAPE la plus faible ({modelResults[modelResults.bestModel]?.eval?.MAPE}%).
                    </p>
                  </div>

                  <div className="bg-[#EAF6F0]/60 border border-[#38B987]/30 p-4 rounded-xl">
                    <div className="text-xs font-extrabold text-[#123D32] uppercase tracking-wider">Saisonnalité Commerciale</div>
                    <div className="text-lg font-black text-[#168568] mt-1">Saison Forte T4</div>
                    <p className="text-xs text-slate-600 mt-1">
                      Augmentation moyenne prédictible de +35% sur les mois de Novembre et Décembre.
                    </p>
                  </div>

                  <div className="bg-[#EAF6F0]/60 border border-[#38B987]/30 p-4 rounded-xl">
                    <div className="text-xs font-extrabold text-[#123D32] uppercase tracking-wider">Projection à +{horizon} Mois</div>
                    <div className="text-lg font-black text-[#168568] mt-1">
                      {formatCurrency(sumArray(modelResults[modelResults.bestModel]?.predictions))}
                    </div>
                    <p className="text-xs text-slate-600 mt-1">
                      Total du chiffre d'affaires projeté sur la période choisie.
                    </p>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* ================= TAB 2 : DONNÉES & IMPORT ================= */}
          {activeTab === 'data' && (
            <div className="space-y-6">
              {/* ZONE DROPFILE */}
              <div className="bg-white border border-slate-200/80 rounded-2xl p-8 shadow-sm">
                <h3 className="text-[#123D32] font-bold text-lg mb-1">Importation des données ventes</h3>
                <p className="text-xs text-slate-500 mb-6">Chargez un fichier CSV avec vos colonnes Date (YYYY-MM) et Ventes/Chiffre d'affaires.</p>

                <div className="border-2 border-dashed border-[#38B987]/40 hover:border-[#168568] bg-[#EAF6F0]/40 rounded-2xl p-10 flex flex-col items-center justify-center transition-all cursor-pointer">
                  <div className="w-14 h-14 rounded-2xl bg-[#168568] text-white flex items-center justify-center shadow-md mb-4">
                    <Icons.Import />
                  </div>
                  <p className="text-sm font-bold text-[#123D32]">Glissez-déposez votre fichier CSV ici</p>
                  <p className="text-xs text-slate-500 mt-1">Détection automatique des séparateurs (, ; tab)</p>
                  
                  <input
                    type="file"
                    accept=".csv, .txt"
                    onChange={handleFileUpload}
                    className="mt-4 text-xs text-slate-600 file:mr-4 file:py-2.5 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-[#168568] file:text-white hover:file:bg-[#123D32] cursor-pointer"
                  />
                </div>
              </div>

              {/* TABLEAU MODERNE DES DONNÉES */}
              <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm overflow-hidden">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-[#123D32] font-bold text-base">Données Chargées ({dataset.length} lignes)</h3>
                  <button
                    onClick={() => setDataset([])}
                    className="text-xs font-bold text-rose-600 hover:text-rose-800 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-50"
                  >
                    <Icons.Trash /> Reinitialiser les données
                  </button>
                </div>

                <div className="max-h-96 overflow-y-auto rounded-xl border border-slate-100">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#EAF6F0] text-[#123D32] uppercase font-bold sticky top-0 border-b border-emerald-100">
                      <tr>
                        <th className="px-6 py-3.5">Mois / Date</th>
                        <th className="px-6 py-3.5">Chiffre d'Affaires (€)</th>
                        <th className="px-6 py-3.5">Volume Vendu</th>
                        <th className="px-6 py-3.5">Prix Moyen Unitaire</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {dataset.map((row, idx) => (
                        <tr key={idx} className="hover:bg-[#EAF6F0]/50 transition-colors">
                          <td className="px-6 py-3 font-semibold text-[#123D32]">{row.date}</td>
                          <td className="px-6 py-3 font-bold text-[#168568]">{formatCurrency(row.revenue)}</td>
                          <td className="px-6 py-3 text-slate-700">{formatNumber(row.volume)}</td>
                          <td className="px-6 py-3 text-slate-500">{formatCurrency(row.revenue / (row.volume || 1))}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ================= TAB 3 : PRÉVISIONS & MODÈLES ================= */}
          {activeTab === 'forecast' && (
            <div className="space-y-6">

              {/* SELECTEURS & PARAMÈTRES DE PRÉVISION */}
              <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-sm flex flex-wrap items-center justify-between gap-4">
                <div className="flex flex-wrap items-center gap-6">
                  <div>
                    <span className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Métrique d'Analyse</span>
                    <div className="flex bg-[#F5F7F6] p-1 rounded-xl border border-slate-200 text-xs font-bold">
                      <button
                        onClick={() => setTargetMetric('revenue')}
                        className={`px-4 py-2 rounded-lg transition-all ${targetMetric === 'revenue' ? 'bg-[#168568] text-white shadow' : 'text-slate-600 hover:text-[#123D32]'}`}
                      >
                        Chiffre d'Affaires (€)
                      </button>
                      <button
                        onClick={() => setTargetMetric('volume')}
                        className={`px-4 py-2 rounded-lg transition-all ${targetMetric === 'volume' ? 'bg-[#168568] text-white shadow' : 'text-slate-600 hover:text-[#123D32]'}`}
                      >
                        Volume Vendu
                      </button>
                    </div>
                  </div>

                  <div>
                    <span className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Horizon de Prédiction</span>
                    <div className="flex bg-[#F5F7F6] p-1 rounded-xl border border-slate-200 text-xs font-bold">
                      {[3, 6, 12].map(h => (
                        <button
                          key={h}
                          onClick={() => setHorizon(h)}
                          className={`px-4 py-2 rounded-lg transition-all ${horizon === h ? 'bg-[#123D32] text-white shadow' : 'text-slate-600 hover:text-[#123D32]'}`}
                        >
                          +{h} Mois
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleSaveForecast}
                  className="bg-[#168568] hover:bg-[#123D32] text-white font-bold text-xs px-5 py-3 rounded-xl flex items-center gap-2 shadow-sm transition-all"
                >
                  <Icons.Check /> Enregistrer le Rapport
                </button>
              </div>

              {/* COMPARAISON DES 3 MODÈLES */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                
                {/* CARD HOLT-WINTERS */}
                <div className={`bg-white border rounded-2xl p-5 shadow-sm relative transition-all ${
                  modelResults.bestModel === 'hw' ? 'border-[#168568] ring-2 ring-[#168568]/20 bg-[#EAF6F0]/20' : 'border-slate-200/80'
                }`}>
                  {modelResults.bestModel === 'hw' && (
                    <span className="absolute -top-3 right-4 bg-[#168568] text-white text-[10px] font-extrabold px-3 py-0.5 rounded-full shadow-sm">
                      RECOMMANDÉ (MEILLEUR MAPE)
                    </span>
                  )}
                  <div className="text-sm font-extrabold text-[#123D32]">Holt-Winters Triple Exponentiel</div>
                  <p className="text-xs text-slate-500 mt-1">Intègre la tendance globale et les variations saisonnières.</p>

                  <div className="mt-4 pt-3 border-t border-slate-100 space-y-2 text-xs">
                    <div className="flex justify-between font-bold"><span className="text-slate-500">MAPE (Erreur) :</span><span className="text-[#168568]">{modelResults.hw?.eval?.MAPE}%</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">RMSE :</span><span className="text-slate-800 font-semibold">{formatNumber(modelResults.hw?.eval?.RMSE)}</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">MAE :</span><span className="text-slate-800 font-semibold">{formatNumber(modelResults.hw?.eval?.MAE)}</span></div>
                  </div>
                </div>

                {/* CARD RÉGRESSION LINÉAIRE */}
                <div className={`bg-white border rounded-2xl p-5 shadow-sm relative transition-all ${
                  modelResults.bestModel === 'lr' ? 'border-[#168568] ring-2 ring-[#168568]/20 bg-[#EAF6F0]/20' : 'border-slate-200/80'
                }`}>
                  {modelResults.bestModel === 'lr' && (
                    <span className="absolute -top-3 right-4 bg-[#168568] text-white text-[10px] font-extrabold px-3 py-0.5 rounded-full shadow-sm">
                      RECOMMANDÉ
                    </span>
                  )}
                  <div className="text-sm font-extrabold text-[#123D32]">Régression Linéaire OLS</div>
                  <p className="text-xs text-slate-500 mt-1">Calcule la trajectoire linéaire moyenne des ventes.</p>

                  <div className="mt-4 pt-3 border-t border-slate-100 space-y-2 text-xs">
                    <div className="flex justify-between font-bold"><span className="text-slate-500">MAPE (Erreur) :</span><span className="text-[#168568]">{modelResults.lr?.eval?.MAPE}%</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">RMSE :</span><span className="text-slate-800 font-semibold">{formatNumber(modelResults.lr?.eval?.RMSE)}</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">MAE :</span><span className="text-slate-800 font-semibold">{formatNumber(modelResults.lr?.eval?.MAE)}</span></div>
                  </div>
                </div>

                {/* CARD MOYENNE MOBILE */}
                <div className={`bg-white border rounded-2xl p-5 shadow-sm relative transition-all ${
                  modelResults.bestModel === 'ma' ? 'border-[#168568] ring-2 ring-[#168568]/20 bg-[#EAF6F0]/20' : 'border-slate-200/80'
                }`}>
                  {modelResults.bestModel === 'ma' && (
                    <span className="absolute -top-3 right-4 bg-[#168568] text-white text-[10px] font-extrabold px-3 py-0.5 rounded-full shadow-sm">
                      RECOMMANDÉ
                    </span>
                  )}
                  <div className="text-sm font-extrabold text-[#123D32]">Moyenne Mobile SMA-3</div>
                  <p className="text-xs text-slate-500 mt-1">Lissage des fluctuations sur fenêtre glissante de 3 mois.</p>

                  <div className="mt-4 pt-3 border-t border-slate-100 space-y-2 text-xs">
                    <div className="flex justify-between font-bold"><span className="text-slate-500">MAPE (Erreur) :</span><span className="text-[#168568]">{modelResults.ma?.eval?.MAPE}%</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">RMSE :</span><span className="text-slate-800 font-semibold">{formatNumber(modelResults.ma?.eval?.RMSE)}</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">MAE :</span><span className="text-slate-800 font-semibold">{formatNumber(modelResults.ma?.eval?.MAE)}</span></div>
                  </div>
                </div>

              </div>

              {/* GRAPHIQUE VERT PREMIUM */}
              <PremiumGreenChart
                historicalData={dataset}
                modelResults={modelResults}
                selectedHorizon={horizon}
                targetMetric={targetMetric}
              />

              {/* TABLEAU DES PRÉDICTION DE SÉRIE CHRONOLOGIQUE */}
              <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm">
                <h3 className="text-[#123D32] font-bold text-base mb-4">Projections Détaillées (+{horizon} mois)</h3>

                <div className="overflow-x-auto rounded-xl border border-slate-100">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#EAF6F0] text-[#123D32] uppercase font-bold border-b border-emerald-100">
                      <tr>
                        <th className="px-6 py-3.5">Mois Futur</th>
                        <th className="px-6 py-3.5 text-[#168568]">Holt-Winters (Recommandé)</th>
                        <th className="px-6 py-3.5 text-[#38B987]">Régression Linéaire</th>
                        <th className="px-6 py-3.5 text-slate-600">Moyenne Mobile</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {Array.from({ length: horizon }).map((_, i) => {
                        const lastDate = dataset[dataset.length - 1]?.date || '2025-12';
                        const futureDate = addMonthsToDate(lastDate, i + 1);
                        const hwVal = modelResults.hw?.predictions[i] || 0;
                        const lrVal = modelResults.lr?.predictions[i] || 0;
                        const maVal = modelResults.ma?.predictions[i] || 0;

                        return (
                          <tr key={i} className="hover:bg-[#EAF6F0]/40 transition-colors">
                            <td className="px-6 py-3.5 font-bold text-[#123D32]">{futureDate}</td>
                            <td className="px-6 py-3.5 font-extrabold text-[#168568]">{targetMetric === 'revenue' ? formatCurrency(hwVal) : formatNumber(hwVal)}</td>
                            <td className="px-6 py-3.5 font-bold text-[#38B987]">{targetMetric === 'revenue' ? formatCurrency(lrVal) : formatNumber(lrVal)}</td>
                            <td className="px-6 py-3.5 text-slate-600">{targetMetric === 'revenue' ? formatCurrency(maVal) : formatNumber(maVal)}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* ================= TAB 4 : CHATBOT GEMINI IA ================= */}
          {activeTab === 'chat' && (
            <div className="h-[calc(100vh-170px)] flex flex-col bg-white border border-slate-200/80 rounded-2xl shadow-sm overflow-hidden">
              
              {/* TOP CHATBOT */}
              <div className="p-4 border-b border-slate-100 bg-[#123D32] text-white flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-[#168568] flex items-center justify-center text-white">
                    <Icons.Bot />
                  </div>
                  <div>
                    <div className="font-bold text-sm text-white">Assistant Stratégique Gemini</div>
                    <div className="text-[10px] text-emerald-300">Analyse contextuelle des prévisions en direct</div>
                  </div>
                </div>
                <span className="text-[10px] font-bold bg-[#38B987] text-[#123D32] px-2.5 py-1 rounded-full">
                  Gemini API Actif
                </span>
              </div>

              {/* MESSAGES */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-[#F5F7F6]/50">
                {chatMessages.map((msg, idx) => (
                  <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-xl rounded-2xl p-4 text-xs leading-relaxed ${
                      msg.role === 'user'
                        ? 'bg-[#168568] text-white rounded-br-none shadow-sm font-medium'
                        : 'bg-[#EAF6F0] text-[#123D32] border border-[#38B987]/30 rounded-bl-none shadow-sm font-medium'
                    }`}>
                      <div className="whitespace-pre-line">{msg.text}</div>
                    </div>
                  </div>
                ))}
                {isChatLoading && (
                  <div className="flex justify-start">
                    <div className="bg-[#EAF6F0] border border-[#38B987]/30 text-[#123D32] rounded-2xl p-4 text-xs flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#168568] animate-bounce"></span>
                      <span className="w-2 h-2 rounded-full bg-[#168568] animate-bounce [animation-delay:0.2s]"></span>
                      <span className="w-2 h-2 rounded-full bg-[#168568] animate-bounce [animation-delay:0.4s]"></span>
                      Traitement de vos données par Gemini AI...
                    </div>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>

              {/* PILULES SUGGESTIONS ET INPUT */}
              <div className="p-4 border-t border-slate-100 bg-white space-y-3">
                <div className="flex flex-wrap gap-2 text-xs">
                  {[
                    "Pourquoi choisir Holt-Winters ?",
                    "Quel est le CA estimé à +6 mois ?",
                    "Conseils pour optimiser mes stocks T4 ?"
                  ].map((pill, i) => (
                    <button
                      key={i}
                      onClick={() => setInputQuery(pill)}
                      className="bg-[#EAF6F0] hover:bg-[#38B987]/20 text-[#123D32] font-semibold px-3 py-1.5 rounded-full transition-all border border-[#38B987]/20"
                    >
                      {pill}
                    </button>
                  ))}
                </div>

                <form onSubmit={handleSendChatMessage} className="flex gap-2">
                  <input
                    type="text"
                    value={inputQuery}
                    onChange={(e) => setInputQuery(e.target.value)}
                    placeholder="Posez votre question sur vos ventes..."
                    className="flex-1 bg-[#F5F7F6] border border-slate-200 rounded-xl px-4 py-3 text-xs font-medium text-slate-800 focus:outline-none focus:border-[#168568]"
                  />
                  <button
                    type="submit"
                    disabled={isChatLoading || !inputQuery.trim()}
                    className="bg-[#168568] hover:bg-[#123D32] disabled:opacity-50 text-white font-bold px-5 py-3 rounded-xl transition-all shadow-sm flex items-center gap-2"
                  >
                    <Icons.Send />
                  </button>
                </form>
              </div>

            </div>
          )}

          {/* ================= TAB 5 : HISTORIQUE ================= */}
          {activeTab === 'history' && (
            <div className="space-y-6">
              <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm">
                <h3 className="text-[#123D32] font-bold text-base mb-4">Historique des Rapports Enregistrés</h3>

                {historySaved.length === 0 ? (
                  <div className="text-center py-12 text-slate-400 text-xs font-medium">
                    Aucun rapport n'a été enregistré. Générez une prévision puis cliquez sur "Enregistrer le Rapport".
                  </div>
                ) : (
                  <div className="overflow-x-auto rounded-xl border border-slate-100">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-[#EAF6F0] text-[#123D32] uppercase font-bold border-b border-emerald-100">
                        <tr>
                          <th className="px-6 py-3.5">Date & Heure</th>
                          <th className="px-6 py-3.5">Horizon</th>
                          <th className="px-6 py-3.5">Modèle Sélectionné</th>
                          <th className="px-6 py-3.5">Erreur (MAPE)</th>
                          <th className="px-6 py-3.5">Total Projeté</th>
                          <th className="px-6 py-3.5 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {historySaved.map((item) => (
                          <tr key={item.id} className="hover:bg-[#EAF6F0]/40 transition-colors">
                            <td className="px-6 py-4 font-semibold text-slate-600">{item.timestamp}</td>
                            <td className="px-6 py-4 font-bold text-[#123D32]">+{item.horizon} mois</td>
                            <td className="px-6 py-4 font-extrabold text-[#168568]">{item.bestModel}</td>
                            <td className="px-6 py-4 font-bold text-[#38B987]">{item.mape}%</td>
                            <td className="px-6 py-4 font-black text-[#123D32]">{formatCurrency(item.projectedSum)}</td>
                            <td className="px-6 py-4 text-right">
                              <button
                                onClick={() => handleDeleteHistory(item.id)}
                                className="text-xs font-bold text-rose-600 hover:text-rose-800 bg-rose-50 px-3 py-1.5 rounded-lg"
                              >
                                Supprimer
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ================= TAB 6 : CONFIGURATION ================= */}
          {activeTab === 'settings' && (
            <div className="space-y-6 max-w-4xl">
              
              {/* GOOGLE GEMINI CONFIG */}
              <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#EAF6F0] text-[#168568] flex items-center justify-center">
                    <Icons.Bot />
                  </div>
                  <div>
                    <h3 className="text-[#123D32] font-bold text-base">Connexion Google Gemini</h3>
                    <p className="text-xs text-slate-500">La clé API est conservée côté serveur pour éviter de l’exposer dans le navigateur.</p>
                  </div>
                </div>
                <div className="bg-[#EAF6F0] border border-[#38B987]/30 rounded-xl p-4 text-xs text-[#123D32]">
                  Pour activer le chatbot en ligne, ajoutez la variable <strong>GEMINI_API_KEY</strong> dans les paramètres du projet Vercel, puis redéployez l’application. Ne collez jamais votre clé API dans le code public.
                </div>
              </div>

              {/* SUPABASE CONNECTOR */}
              <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#EAF6F0] text-[#168568] flex items-center justify-center">
                      <Icons.Settings />
                    </div>
                    <div>
                      <h3 className="text-[#123D32] font-bold text-base">Base de Données Supabase</h3>
                      <p className="text-xs text-slate-500">Synchronisez automatiquement l'historique dans votre Cloud PostgreSQL.</p>
                    </div>
                  </div>

                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" checked={useSupabase} onChange={(e) => setUseSupabase(e.target.checked)} className="sr-only peer" />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#168568]"></div>
                  </label>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-600 mb-1">URL Supabase Project</label>
                    <input
                      type="text"
                      value={supabaseUrl}
                      onChange={(e) => setSupabaseUrl(e.target.value)}
                      placeholder="https://xyz.supabase.co"
                      className="w-full bg-[#F5F7F6] border border-slate-200 rounded-xl px-4 py-3 text-xs font-medium text-slate-800 focus:outline-none focus:border-[#168568]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-600 mb-1">Clé Publique Anon</label>
                    <input
                      type="password"
                      value={supabaseKey}
                      onChange={(e) => setSupabaseKey(e.target.value)}
                      placeholder="eyJhbGci..."
                      className="w-full bg-[#F5F7F6] border border-slate-200 rounded-xl px-4 py-3 text-xs font-medium text-slate-800 focus:outline-none focus:border-[#168568]"
                    />
                  </div>
                </div>

                <div className="bg-[#EAF6F0] p-4 rounded-xl border border-[#38B987]/20">
                  <div className="text-xs font-bold text-[#123D32] mb-1.5">Structure SQL Requise :</div>
                  <pre className="text-[11px] text-[#168568] font-mono overflow-x-auto p-2 bg-white rounded-lg border border-slate-200">
{`CREATE TABLE forecasts_history (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  target_metric TEXT,
  horizon INT,
  best_model TEXT,
  mape NUMERIC,
  projected_sum NUMERIC
);`}
                  </pre>
                </div>
              </div>

            </div>
          )}

        </div>
      </main>
    </div>
  );
}